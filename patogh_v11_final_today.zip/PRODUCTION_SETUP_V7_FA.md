# راه‌اندازی Production پاتوق v7

## 1) Supabase

فایل‌ها را به ترتیب در SQL Editor اجرا کن:

```text
backend/supabase/schema.sql
backend/supabase/v6_roles_social.sql
backend/supabase/v7_ecosystem.sql
backend/supabase/v7_seed_demo.sql  (اختیاری)
```

## 2) Auth

Phone Auth و SMS Provider را در Supabase فعال کن.
در Demo کد `1234` فعال است؛ Production از OTP واقعی استفاده می‌کند.

## 3) Firebase / Push

از template موجود در `production_templates` استفاده کن و مقادیر Firebase Web/Android را اضافه کن.
FCM برای دعوت اسپانسری، آزاد شدن Waitlist، یادآوری رویداد و پیام‌های مهم استفاده می‌شود.

## 4) پرداخت

Payment Edge Functionهای قبلی داخل backend موجودند.
Secret درگاه هرگز داخل Flutter قرار نگیرد.
برای سفارش منوی میزبان، رزرو گروهی، جریمه و پرداخت سازمانی Endpointهای Backend باید به Provider نهایی متصل شوند.

## 5) No-show

Migration v7 دو Function مهم دارد:

- `user_has_open_debt`
- `apply_no_show_penalty`

`reserve_event` در v7 دوباره تعریف شده تا بدهی باز، رزرو جدید را مسدود کند.

## 6) دعوت اسپانسری

Function:

`can_invite_for_sponsorship`

قبل از ارسال Batch جدید ظرفیت واقعی را چک می‌کند. Worker/Edge Function ارسال دعوت باید قبل از هر Batch آن را فراخوانی کند.

## 7) Build Production

```bash
flutter build web \
  --release \
  --base-href "/patogh/" \
  --no-web-resources-cdn \
  --dart-define=PATOGH_MODE=production \
  --dart-define=SUPABASE_URL="..." \
  --dart-define=SUPABASE_ANON_KEY="..." \
  --dart-define=PAYMENT_API_BASE_URL="..." \
  --dart-define=FIREBASE_API_KEY="..." \
  --dart-define=FIREBASE_APP_ID="..." \
  --dart-define=FIREBASE_MESSAGING_SENDER_ID="..." \
  --dart-define=FIREBASE_PROJECT_ID="..." \
  --dart-define=FCM_VAPID_KEY="..."
```

## 8) امنیت کودک و داده

پروفایل افراد تحت سرپرستی عمومی نیست. در Production سیاست‌های حریم خصوصی، رضایت سرپرست، تحویل امن کودک و دسترسی محدود به داده‌های کودک باید در Backend و UI enforce شوند.

## 9) جرایم مالی

قبل از Production واقعی، متن شرایط استفاده، مهلت لغو، هزینه No-show، نحوه وصول بدهی و سازوکار اعتراض باید با الزامات قانونی و قراردادی محل فعالیت پاتوق هماهنگ شود.
