# معماری Production پیشنهادی پاتوق v8

هسته Domain نباید به یک Provider خاص قفل شود.

Flutter/Web/Android
↓
Patogh API / Domain Services
↓
PostgreSQL + Object Storage + Queue/Jobs

Provider Adapterها:

- SMS: ارائه‌دهنده ایرانی یا جایگزین دیگر
- Payment: درگاه ایرانی یا PSP/Payment Aggregator منتخب
- Map: نشان/بلد/OpenStreetMap یا Provider دیگر
- Push: FCM یا جایگزین قابل تعویض
- Storage: S3-compatible Object Storage

فایل `lib/services/provider_contracts.dart` قراردادهای پایه را تعریف می‌کند.

## اصل مهم

Service Role Key، Secret درگاه، SMS Secret و Push Secret هرگز داخل Flutter/Web قرار نمی‌گیرند.

## Location

استان و شهر در Production باید ID محور باشند، نه Text آزاد. جدول‌های `provinces` و `cities` مرجع مشترک پروفایل، رویداد، میزبان، هماهنگ‌کننده، آژانس، سازمان، کمپین و گزارش‌ها هستند.
