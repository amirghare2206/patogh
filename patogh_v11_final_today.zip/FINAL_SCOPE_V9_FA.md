# Scope نهایی پاتوق تا v9

## کاربران و نقش‌ها
- یک حساب با چند نقش همزمان
- شرکت‌کننده، میزبان، هماهنگ‌کننده، برگزارکننده/آژانس، ادمین
- Role Switcher
- درخواست و تأیید نقش حرفه‌ای
- شبکه‌های اجتماعی با Privacy مستقل
- حلقه دوستان و خانواده
- فرزند/Dependent و ثبت‌نام توسط سرپرست

## رویداد
- دسته‌بندی پویا
- سطح محلی/شهری/منطقه‌ای/کشوری
- سن، جنسیت/خانوادگی و شرایط حضور
- عمومی، خصوصی، دعوتی، باشگاهی، سازمانی، اسپانسری و Match-only
- Event Code و آدرس دقیق با زمان‌بندی نمایش
- فرم ثبت‌نام پویا، Terms و Consent
- فردی، گروهی و +1
- Waitlist و Matching
- Familiar Faces و Repeat
- رأی زمان رویداد

## میزبانی
- انواع گسترده میزبان: کافه، رستوران، هتل، بوم‌گردی، شهربازی، خانه بازی، مهدکودک، مسجد، گیم‌کلاب، سالن، مرکز همایش و...
- شعبه و ظرفیت
- منو و پذیرایی
- Billing Policy
- پذیرایی سازمانی
- Reputation میزبان

## اعتماد و کیفیت
- Feedback تأییدشده
- Reputation برای کاربر، میزبان، هماهنگ‌کننده، آژانس و Event
- Claim Match
- Confidence
- Attendance Reputation
- No-show، بدهی، جریمه و محدودیت رزرو
- اعتراض به No-show در معماری

## Social
- Timeline
- Story
- Group / Channel
- Chat
- Shared Event Album
- Patogh Memories: عکس، ویدئو، متن، صوت، دفتر یادگاری
- دسترسی شخصی/رویداد/حلقه/عمومی
- Memory Capsule و Anniversary

## دعوت‌نامه و مراسم شخصی
- عروسی، تولد، نامزدی، سالگرد، دورهمی، فارغ‌التحصیلی، یادبود/عزا
- دعوت با موبایل، username یا Circle
- RSVP و +1
- آدرس خصوصی برای مهمان تأییدشده
- تبدیل صفحه مراسم به آلبوم خاطره بعد از پایان

## سازمانی و تجاری
- B2C
- B2B
- B2E
- حساب سازمانی و بودجه رفاهی
- درخواست سازمانی و Proposal
- Sponsorship کامل/جزئی
- دعوت ظرفیت‌محور کاربران واجد شرایط
- توقف دعوت بعد از تکمیل ظرفیت در معماری

## رویداد بزرگ
- همایش/سمینار/کنفرانس
- Ticket Tier
- Registration Code / QR-ready
- Check-in Staff
- Session / Agenda
- Speaker
- Sponsor Booth
- Certificate-ready

## Growth
- Discount Code
- Campaign
- Festival
- Banner Engine با Placement و Audience
- Membership Club
- AI Concierge Demo

## مکان
- 31 استان ایران در UI Demo
- انتخاب استان/شهر یکپارچه
- Schema قابل Seed شدن از دیتاست رسمی برای Production

## Backend
- PostgreSQL/Supabase reference schema
- RLS
- Provider abstraction برای SMS، Payment، Map، Object Storage و Push
- Production secrets فقط سمت Backend
