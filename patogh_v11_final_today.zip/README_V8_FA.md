# پاتوق v8 — Master Preview

این نسخه «نسخه مرجع تا این نقطه» است و روی v7 ساخته شده است.

## تغییرات اصلی v8

- Home مرکزی چندسرویسی؛ رزرو فقط یکی از سرویس‌های پاتوق است
- حفظ الگوی UX قبلی: Story، Search، Location، Banner، Service Cards و Event Discovery
- نقش‌های چندگانه برای یک حساب؛ شرکت‌کننده + میزبان + هماهنگ‌کننده + برگزارکننده
- Role Switcher برای جابه‌جایی بین پنل‌ها
- انتخاب استان و شهر در UI مشترک
- شبکه‌های اجتماعی ایرانی و خارجی با Privacy مستقل برای هر لینک
- «حلقه من» برای دوستان و خانواده + مجوز اعلان شرکت در رویداد
- Familiar Faces
- ارتباط مجدد دوطرفه بعد از رویداد
- Find a Time / رأی زمان
- Dynamic Registration Questions
- Event Consent / Terms در Schema
- Membership Clubs
- Shared Event Album
- Check-in Only Staff در Schema
- AI Concierge Demo
- Event Code / delayed exact address در Schema
- Visibility: عمومی، لینک خصوصی، دعوتی، اعضا، سازمانی، اسپانسری و فقط Match شده
- Venue Billing Policy: پیش‌خرید، پرداخت در محل، حداقل سفارش، پکیج، صورتحساب جدا/گروهی
- Provider-independent contracts برای SMS، Payment، Map، Storage و Push

## چیزهایی که از v7 حفظ شده‌اند

- پنج حوزه نقش اصلی و پنل ادمین
- Reputation/Feedback/Claim Match
- درخواست رویداد
- رزرو گروهی و فرزند وابسته
- رده‌بندی جغرافیایی/سنی/جنسیتی رویداد
- انواع گسترده میزبان از کافه تا شهربازی و مهدکودک
- منوی میزبان و Checkout
- تخفیف، کمپین و Banner Engine
- B2C/B2B/B2E
- Sponsorship
- No-show، بدهی و Attendance Reputation
- Timeline، Story، Group/Channel

## نصب Demo

محتویات ZIP را روی ریشه پروژه Merge کن؛ `lib` و `test` جایگزین شوند و `.github` فعلی را نگه دار.

```bash
bash install_v8.sh
```

## Backend

ترتیب Migration:

1. `backend/supabase/schema.sql`
2. `backend/supabase/v6_roles_social.sql`
3. `backend/supabase/v7_ecosystem.sql`
4. `backend/supabase/v8_master.sql`
5. `backend/supabase/v8_location_seed.sql`

## نکته مکان

UI آفلاین v8 تمام 31 استان را دارد و برای Demo یک کاتالوگ وسیع شهر/مرکز شهری داخل اپ قرار داده شده است. برای Production باید جدول `cities` از آخرین دیتاست رسمی/تأییدشده تقسیمات کشوری Seed شود تا منبع داده قابل به‌روزرسانی و مستقل از سورس Flutter باشد.
