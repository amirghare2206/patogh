# مواردی که برای Production واقعی نیاز به اتصال سرویس دارند

این‌ها نقص طراحی نیستند؛ به Provider/کلید/زیرساخت واقعی نیاز دارند:

- OTP واقعی و SMS
- درگاه پرداخت و Verify/Refund
- Object Storage و signed URL برای عکس/ویدئو/صوت
- Push Notification
- نقشه و Geocoding
- ارسال SMS دعوت‌نامه مهمان خارج از پاتوق
- Job Scheduler برای Anniversary و Reminder
- دیتاست رسمی و به‌روز شهرهای ایران
- Signing Android/iOS
- Moderation رسانه و گزارش‌های Abuse
- بک‌اند Production مستقل/مقیاس‌پذیر در صورت خروج از Supabase
