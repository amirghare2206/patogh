#!/usr/bin/env bash
set -euo pipefail

echo "== Patogh v9 final reference setup =="

flutter pub add \
  shared_preferences \
  supabase_flutter \
  firebase_core \
  firebase_messaging \
  http \
  url_launcher

dart format lib test
flutter analyze
flutter test
flutter build web --release --base-href "/patogh/" --no-web-resources-cdn

echo
echo "Patogh v9 Demo build completed successfully."
echo "Production migration: backend/supabase/v9_final.sql"
