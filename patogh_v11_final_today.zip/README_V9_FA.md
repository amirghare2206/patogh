# پاتوق v9 — Final Reference Preview

این نسخه جمع‌بندی یکپارچه همه نیازهای محصول تا این نقطه است و روی v8 ساخته شده است.

## هسته محصول

- Home چندسرویسی و Discovery رویداد
- رزرو فردی، گروهی و رزرو فرزند توسط سرپرست
- نقش‌های چندگانه برای یک حساب و Role Switcher
- میزبان، هماهنگ‌کننده، برگزارکننده/آژانس، شرکت‌کننده و ادمین
- انتخاب استان و شهر ایران در همه جریان‌های مکانی
- رده‌بندی رویداد: محلی، شهری، منطقه‌ای و کشوری
- رده سنی، سیاست حضور و شرایط خانوادگی/جنسیتی
- Matching، Familiar Faces، Repeat و Group Quality
- منوی میزبان و پیش‌سفارش پذیرایی
- کد تخفیف، جشنواره، Banner Engine و Sponsorship
- B2C، B2B و B2E
- Reputation، Review، Claim Match، Attendance Reputation و No-show
- Timeline، Story، Group، Channel و Chat
- حلقه دوستان/خانواده و لینک شبکه‌های اجتماعی با Privacy
- درخواست رویداد، Find a Time، Membership Club و AI Concierge

## افزوده‌های نهایی v9

### Patogh Memories
- آلبوم و خاطرات داخل خود رویداد
- عکس، ویدئو، متن، صوت و دفتر یادگاری
- سطح دسترسی مستقل برای هر محتوا: شخصی، اعضای رویداد، حلقه یا Timeline
- مدت نگهداری قابل انتخاب در فضای مشترک
- نگهداری نسخه شخصی حتی پس از انقضای نمایش مشترک در معماری Production
- Memory Capsule و سالگرد رویداد
- صفحه «خاطرات و سالگردها» در پروفایل و Home
- اصلاح RLS آلبوم v8 تا محتوای رویداد برای همه کاربران لاگین‌شده باز نباشد

### Patogh Invitations
- مراسم خصوصی: تولد، عروسی، نامزدی، سالگرد، دورهمی، فارغ‌التحصیلی، یادبود/عزا و سایر
- کارت دعوت دیجیتال
- دعوت با شماره تلفن، نام کاربری پاتوق یا حلقه
- RSVP: می‌آید، نمی‌آید، شاید
- امکان همراه (+1)
- نمایش آدرس دقیق فقط برای مهمان‌های تأییدشده در Backend
- بعد از مراسم، همان صفحه می‌تواند به کپسول خاطرات تبدیل شود

### Conference / Large Event Mode
- ثبت‌نام همایش، سمینار و کنفرانس
- بلیت عادی، دانشجویی و VIP
- QR/Registration Code و Check-in
- Agenda / Session
- Speaker
- Sponsor Booth
- گواهی حضور
- نظرسنجی و آلبوم پس از رویداد در معماری

## نصب Demo

محتویات ZIP را روی ریشه پروژه Merge کن. `lib` و `test` جایگزین شوند و `.github` فعلی را نگه دار.

```bash
bash install_v9.sh
```

## ترتیب Migration Production

1. `backend/supabase/schema.sql`
2. `backend/supabase/v6_roles_social.sql`
3. `backend/supabase/v7_ecosystem.sql`
4. `backend/supabase/v8_master.sql`
5. `backend/supabase/v8_location_seed.sql`
6. `backend/supabase/v9_final.sql`

## نکته مهم Production

این بسته یک Reference Preview کامل برای UI/Flow/Schema است. SMS واقعی، پرداخت، Upload واقعی رسانه، Push، نقشه و دعوت SMS باید با Providerهای واقعی انتخاب‌شده متصل شوند. Secretهای درگاه و Service Role هرگز نباید داخل Flutter/Web قرار بگیرند.
