# معماری Production پاتوق v9

## اصل مهم
Flutter نباید به منطق تجاری یک Provider خاص قفل شود. SMS، پرداخت، Storage، Map و Push از طریق Adapter/Service Layer متصل شوند.

## لایه‌های اصلی
- Identity & Multi-role
- Event & Reservation Engine
- Venue / Organizer / Coordinator Marketplace
- Trust, Reputation & Feedback Engine
- Social Graph / Circle / Community
- Timeline / Story
- Memories & Anniversary Engine
- Invitation / RSVP Engine
- Conference Engine
- Discount / Campaign / Banner Engine
- Sponsorship
- B2B / B2E
- Attendance / No-show / Debt

## Storage
رسانه‌های Event، Story، Timeline، Menu، Banner و Memories روی Object Storage باشند؛ دیتابیس فقط object key و metadata را نگه دارد.

## Privacy
Memory و Social Linkها ACL مستقل دارند. دسترسی عکس و خاطره رویداد باید با signed URL کوتاه‌عمر صادر شود و RLS به‌تنهایی جایگزین کنترل Object Storage نیست.

## Invitation
دعوت مهمان خارج از پاتوق با token یک‌بارمصرف/قابل انقضا انجام شود. پاسخ RSVP مهمان بدون حساب از طریق Backend/Edge Function انجام شود؛ دسترسی مستقیم anonymous به جدول invitation داده نشود.

## Anniversary Jobs
یک Job روزانه سالگردهای فعال را پیدا کند و فقط برای کاربرانی که subscription فعال دارند Notification بسازد.
